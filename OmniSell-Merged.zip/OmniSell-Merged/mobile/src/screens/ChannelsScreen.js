import { useCallback, useEffect, useState } from "react";
import { Alert, FlatList, RefreshControl, Text, TextInput, TouchableOpacity, View } from "react-native";
import { checkConnection, createConnection, deleteConnection, getConnections } from "../api";
import { s } from "../ui";

const CHANNELS = ["DEMO", "SHOPIFY"];

export default function ChannelsScreen() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);
  const [channel, setChannel] = useState("DEMO");
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [token, setToken] = useState("");

  const load = useCallback(async () => {
    setLoading(true); setErr("");
    try { setItems(await getConnections()); } catch (e) { setErr(e.message); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function connect() {
    setErr("");
    try {
      await createConnection({ channel, name: name.trim(), shop_domain: domain.trim(), access_token: token.trim() });
      setName(""); setDomain(""); setToken(""); setShow(false); load();
    } catch (e) { setErr(e.message); }
  }

  async function recheck(id) {
    try { await checkConnection(id); load(); } catch (e) { setErr(e.message); }
  }

  function remove(c) {
    Alert.alert("Connection hataani hai?", c.name, [
      { text: "Cancel", style: "cancel" },
      { text: "Hatao", style: "destructive", onPress: async () => {
        try { await deleteConnection(c.id); load(); } catch (e) { setErr(e.message); }
      } },
    ]);
  }

  return (
    <View style={s.screen}>
      <Text style={s.title}>Channels</Text>
      {!!err && <Text style={s.err}>{err}</Text>}
      <TouchableOpacity style={s.btn} onPress={() => setShow(!show)}>
        <Text style={s.btnText}>{show ? "Cancel" : "+ Connect channel"}</Text>
      </TouchableOpacity>
      {show && (
        <View>
          <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
            {CHANNELS.map((c) => (
              <TouchableOpacity key={c} style={[s.chip, channel === c && s.chipOn]} onPress={() => setChannel(c)}>
                <Text style={s.chipText}>{c}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput style={s.input} placeholder="Naam (jaise My Shopify Store)" placeholderTextColor="#777" value={name} onChangeText={setName} />
          {channel === "SHOPIFY" && (
            <TextInput style={s.input} placeholder="mystore.myshopify.com" placeholderTextColor="#777" autoCapitalize="none" value={domain} onChangeText={setDomain} />
          )}
          <TextInput style={s.input} placeholder={channel === "DEMO" ? "Token: demo" : "Shopify access token"} placeholderTextColor="#777" autoCapitalize="none" secureTextEntry value={token} onChangeText={setToken} />
          <TouchableOpacity style={s.btn} onPress={connect}><Text style={s.btnText}>Connect</Text></TouchableOpacity>
        </View>
      )}
      <FlatList data={items} keyExtractor={(i) => i.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor="#fff" />}
        ListEmptyComponent={<Text style={s.sub}>Koi channel connect nahi. Pehle DEMO try karo.</Text>}
        renderItem={({ item }) => (
          <View style={s.card}>
            <Text style={s.name}>{item.name}</Text>
            <Text style={s.sub}>{item.channel} {item.shop_domain && item.shop_domain !== "demo" ? "• " + item.shop_domain : ""}</Text>
            <Text style={{ color: item.status === "CONNECTED" ? "#4cd964" : "#ff6b6b", marginTop: 4, fontWeight: "700" }}>{item.status}</Text>
            {!!item.last_error && <Text style={s.err}>{item.last_error}</Text>}
            <View style={s.row}>
              <TouchableOpacity style={[s.btn, { flex: 1, backgroundColor: "#262a35" }]} onPress={() => recheck(item.id)}><Text style={s.btnText}>Re-check</Text></TouchableOpacity>
              <TouchableOpacity style={[s.btn, { flex: 1, backgroundColor: "#c0504d" }]} onPress={() => remove(item)}><Text style={s.btnText}>Hatao</Text></TouchableOpacity>
            </View>
          </View>
        )} />
    </View>
  );
}
