import re

from rest_framework import serializers

from .models import ChannelConnection

SHOP_RE = re.compile(r"^[a-z0-9][a-z0-9-]*\.myshopify\.com$")


class ConnectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChannelConnection
        fields = ["id", "channel", "name", "shop_domain", "status",
                  "last_checked_at", "last_error", "created_at"]


class ConnectionCreateSerializer(serializers.Serializer):
    channel = serializers.ChoiceField(choices=ChannelConnection.Channel.choices)
    name = serializers.CharField(max_length=120)
    shop_domain = serializers.CharField(max_length=200, required=False, allow_blank=True, default="")
    access_token = serializers.CharField(max_length=500, write_only=True)

    def validate(self, attrs):
        if attrs["channel"] == "SHOPIFY":
            d = attrs["shop_domain"].strip().lower()
            d = d.replace("https://", "").replace("http://", "").strip("/")
            # SSRF se bachne ke liye sirf *.myshopify.com allowed
            if not SHOP_RE.match(d):
                raise serializers.ValidationError(
                    {"shop_domain": "Aisa likho: mystore.myshopify.com"})
            attrs["shop_domain"] = d
        else:
            attrs["shop_domain"] = "demo"
        tenant_id = self.context["request"].user.tenant_id
        if ChannelConnection.objects.filter(
                tenant_id=tenant_id, channel=attrs["channel"],
                shop_domain=attrs["shop_domain"]).exists():
            raise serializers.ValidationError("Ye connection pehle se hai.")
        return attrs
