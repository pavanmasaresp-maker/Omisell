from django.utils import timezone
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .adapters.base import AdapterError
from .adapters.registry import get_adapter
from .models import ChannelConnection
from .permissions import ChannelPermission
from .serializers import ConnectionCreateSerializer, ConnectionSerializer


def run_check(conn):
    try:
        get_adapter(conn).health_check()
        conn.status = ChannelConnection.Status.CONNECTED
        conn.last_error = ""
    except AdapterError as e:
        conn.status = ChannelConnection.Status.ERROR
        conn.last_error = str(e)[:300]
    conn.last_checked_at = timezone.now()


class ConnectionViewSet(mixins.ListModelMixin, mixins.DestroyModelMixin,
                        viewsets.GenericViewSet):
    permission_classes = [ChannelPermission]
    serializer_class = ConnectionSerializer
    queryset = ChannelConnection.objects.all()

    def get_queryset(self):
        return super().get_queryset().filter(tenant_id=self.request.user.tenant_id)

    def create(self, request):
        s = ConnectionCreateSerializer(data=request.data, context={"request": request})
        s.is_valid(raise_exception=True)
        d = s.validated_data
        conn = ChannelConnection(tenant_id=request.user.tenant_id, channel=d["channel"],
                                 name=d["name"], shop_domain=d["shop_domain"])
        conn.set_credentials({"access_token": d["access_token"]})
        run_check(conn)
        conn.save()
        return Response(ConnectionSerializer(conn).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def check(self, request, pk=None):
        conn = self.get_object()
        run_check(conn)
        conn.save()
        return Response(ConnectionSerializer(conn).data)
