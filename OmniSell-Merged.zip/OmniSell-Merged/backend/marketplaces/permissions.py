from accounts.permissions import RoleWritePermission


class ChannelPermission(RoleWritePermission):
    """Credentials sensitive hain: sirf Owner/Admin connect ya hata sakte hain."""
    write_roles = {"OWNER", "ADMIN"}
