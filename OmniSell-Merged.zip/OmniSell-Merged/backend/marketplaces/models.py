import json
import uuid

from django.db import models

from . import crypto


class ChannelConnection(models.Model):
    class Channel(models.TextChoices):
        SHOPIFY = "SHOPIFY"
        DEMO = "DEMO"

    class Status(models.TextChoices):
        PENDING = "PENDING"
        CONNECTED = "CONNECTED"
        ERROR = "ERROR"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey("tenants.Tenant", on_delete=models.CASCADE)
    channel = models.CharField(max_length=20, choices=Channel.choices)
    name = models.CharField(max_length=120)
    shop_domain = models.CharField(max_length=200, blank=True)
    credentials_encrypted = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    last_checked_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [models.UniqueConstraint(
            fields=["tenant", "channel", "shop_domain"], name="uniq_tenant_channel_shop")]

    def set_credentials(self, data: dict):
        self.credentials_encrypted = crypto.encrypt(json.dumps(data))

    def get_credentials(self) -> dict:
        if not self.credentials_encrypted:
            return {}
        return json.loads(crypto.decrypt(self.credentials_encrypted))


class ChannelListing(models.Model):
    """Product ka ek channel par status. Publish logic Phase 2b/3 mein aayega."""

    class Status(models.TextChoices):
        PENDING = "PENDING"
        ACTIVE = "ACTIVE"
        FAILED = "FAILED"
        NEEDS_ACTION = "NEEDS_ACTION"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey("tenants.Tenant", on_delete=models.CASCADE)
    connection = models.ForeignKey(ChannelConnection, on_delete=models.CASCADE,
                                   related_name="listings")
    product = models.ForeignKey("catalog.Product", on_delete=models.CASCADE,
                                related_name="listings")
    external_product_id = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    last_error = models.CharField(max_length=300, blank=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(
            fields=["connection", "product"], name="uniq_listing_per_connection_product")]
