from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter(trailing_slash=False)
router.register("connections", views.ConnectionViewSet)
urlpatterns = router.urls
