# OmniSell (Phase 1 + Phase 2a merged)
Sell once. Sync everywhere.

## Backend
cd backend
pip install -r requirements.txt
cp .env.example .env        # DATABASE_URL hata do to SQLite chalega
python manage.py makemigrations accounts tenants catalog inventory marketplaces
python manage.py migrate
python manage.py test
python manage.py runserver 0.0.0.0:8000

Phase 2a adds: `marketplaces` app (channel connections, adapters: base/demo/shopify, registry, crypto for storing credentials encrypted).

## Mobile (Expo)
npx create-expo-app@latest mobile --template blank   # sirf pehli baar
cd mobile && npx expo install expo-secure-store
copy mobile/ files over, then: cp src/config.example.js src/config.js  (URL daalo)
npx expo start --tunnel
