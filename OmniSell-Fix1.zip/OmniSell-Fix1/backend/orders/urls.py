from rest_framework.routers import DefaultRouter
from .views import OrderViewSet, ReturnViewSet

router = DefaultRouter(trailing_slash=False)
# "returns" must be registered BEFORE the empty-prefix order viewset, otherwise
# the order viewset's "<pk>/" pattern greedily matches "returns/" first.
router.register("returns", ReturnViewSet, basename="return")
router.register("", OrderViewSet, basename="order")

urlpatterns = router.urls
