// Codespaces mein port 8000 ka PUBLIC URL yahan daalo (PORTS tab se copy karo).
// Example: https://yourname-abc123-8000.app.github.dev   (aakhir mein / mat lagao)
export const API_URL = "https://PASTE-YOUR-8000-URL-HERE";
