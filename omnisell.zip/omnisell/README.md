# OmniSell
Sell once. Sync everywhere.

Setup:

cd backend
pip install -r requirements.txt
cp .env.example .env
python manage.py makemigrations accounts tenants
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver 0.0.0.0:8000
