from django.contrib import admin
from django.urls import path
from accounts.views import LoginView, MeView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/auth/login", LoginView.as_view()),
    path("api/v1/auth/me", MeView.as_view()),
]
