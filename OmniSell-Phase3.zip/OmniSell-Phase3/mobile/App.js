import { useEffect, useState } from "react";
import { Platform, SafeAreaView, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { me } from "./src/api";
import { clearToken, getToken } from "./src/storage";
import LoginScreen from "./src/screens/LoginScreen";
import DashboardScreen from "./src/screens/DashboardScreen";
import ProductsScreen from "./src/screens/ProductsScreen";
import InventoryScreen from "./src/screens/InventoryScreen";
import ChannelsScreen from "./src/screens/ChannelsScreen";
import OrdersScreen from "./src/screens/OrdersScreen";

const TABS = [["dashboard", "Dashboard"], ["products", "Products"], ["inventory", "Inventory"], ["orders", "Orders"], ["channels", "Channels"]];

export default function App() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState("dashboard");

  async function check() {
    try { if (await getToken()) { await me(); setAuthed(true); } } catch { await clearToken(); }
    setReady(true);
  }
  useEffect(() => { check(); }, []);

  async function logout() { await clearToken(); setAuthed(false); }

  if (!ready) return <View style={{ flex: 1, backgroundColor: "#0f1115" }} />;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#0f1115", paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 }}>
      <StatusBar barStyle="light-content" />
      {!authed ? <LoginScreen onLoggedIn={() => setAuthed(true)} /> : (
        <>
          <View style={{ flex: 1 }}>
            {tab === "dashboard" ? <DashboardScreen /> : tab === "products" ? <ProductsScreen /> : tab === "inventory" ? <InventoryScreen /> : tab === "orders" ? <OrdersScreen /> : <ChannelsScreen />}
          </View>
          <View style={{ flexDirection: "row", backgroundColor: "#1b1e26", paddingVertical: 12 }}>
            {TABS.map(([k, label]) => (
              <TouchableOpacity key={k} style={{ flex: 1, alignItems: "center" }} onPress={() => setTab(k)}>
                <Text style={{ color: tab === k ? "#4f7cff" : "#9aa3b2", fontWeight: "700" }}>{label}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={{ flex: 1, alignItems: "center" }} onPress={logout}>
              <Text style={{ color: "#9aa3b2", fontWeight: "700" }}>Logout</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}
