import { useCallback, useEffect, useState } from "react";
import { Alert, FlatList, RefreshControl, Text, TextInput, TouchableOpacity, View } from "react-native";
import {
  cancelOrder, confirmOrder, createOrder, deliverOrder, getOrders, getSkus,
  packOrder, shipOrder,
} from "../api";
import { s } from "../ui";

const NEXT_ACTION = {
  IMPORTED: { label: "Confirm", fn: confirmOrder },
  CONFIRMED: { label: "Pack", fn: packOrder },
  PACKED: { label: "Ship", fn: (id) => shipOrder(id, {}) },
  SHIPPED: { label: "Mark Delivered", fn: deliverOrder },
};
const CANCELLABLE = new Set(["IMPORTED", "CONFIRMED", "PACKED"]);

export default function OrdersScreen() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("");
  const [show, setShow] = useState(false);
  const [skus, setSkus] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [skuCode, setSkuCode] = useState("");
  const [qty, setQty] = useState("1");

  const load = useCallback(async (st = "") => {
    setLoading(true); setErr("");
    try { setItems(await getOrders(st)); } catch (e) { setErr(e.message); }
    setLoading(false);
  }, []);
  useEffect(() => { load(filter); }, [load, filter]);
  useEffect(() => { getSkus().then(setSkus).catch(() => {}); }, []);

  async function add() {
    const sku = skus.find((k) => k.sku_code.toLowerCase() === skuCode.trim().toLowerCase());
    if (!sku) { setErr(`SKU "${skuCode}" nahi mila.`); return; }
    try {
      await createOrder({
        customer_name: customerName.trim(),
        items: [{ sku: sku.id, quantity: parseInt(qty, 10) || 1 }],
      });
      setCustomerName(""); setSkuCode(""); setQty("1"); setShow(false); load(filter);
    } catch (e) { setErr(e.message); }
  }

  async function act(order, fn) {
    try { await fn(order.id); load(filter); } catch (e) { setErr(e.message); }
  }

  function cancel(order) {
    Alert.alert("Order cancel karni hai?", order.order_number, [
      { text: "Nahi", style: "cancel" },
      { text: "Cancel karo", style: "destructive", onPress: async () => {
        try { await cancelOrder(order.id, "customer/seller request"); load(filter); }
        catch (e) { setErr(e.message); }
      } },
    ]);
  }

  const STATUSES = ["", "IMPORTED", "CONFIRMED", "PACKED", "SHIPPED", "DELIVERED", "CANCELLED"];

  return (
    <View style={s.screen}>
      <Text style={s.title}>Orders</Text>
      {!!err && <Text style={s.err}>{err}</Text>}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 10 }}>
        {STATUSES.map((st) => (
          <TouchableOpacity key={st || "ALL"} style={[s.chip, filter === st && s.chipOn]}
            onPress={() => setFilter(st)}>
            <Text style={s.chipText}>{st || "ALL"}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity style={s.btn} onPress={() => setShow(!show)}>
        <Text style={s.btnText}>{show ? "Cancel" : "+ New order"}</Text>
      </TouchableOpacity>
      {show && (
        <View>
          <TextInput style={s.input} placeholder="Customer name" placeholderTextColor="#777"
            value={customerName} onChangeText={setCustomerName} />
          <TextInput style={s.input} placeholder="SKU code" placeholderTextColor="#777"
            autoCapitalize="characters" value={skuCode} onChangeText={setSkuCode} />
          <TextInput style={s.input} placeholder="Quantity" placeholderTextColor="#777"
            keyboardType="number-pad" value={qty} onChangeText={setQty} />
          <TouchableOpacity style={s.btn} onPress={add}><Text style={s.btnText}>Create order</Text></TouchableOpacity>
        </View>
      )}
      <FlatList data={items} keyExtractor={(i) => i.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => load(filter)} tintColor="#fff" />}
        ListEmptyComponent={<Text style={s.sub}>Koi order nahi.</Text>}
        renderItem={({ item }) => {
          const next = NEXT_ACTION[item.status];
          return (
            <View style={s.card}>
              <Text style={s.name}>{item.order_number} — {item.customer_name || "—"}</Text>
              <Text style={s.sub}>{item.status} • ₹{item.total_amount}</Text>
              {item.items.map((li) => (
                <Text key={li.id} style={s.sub}>  {li.sku_code} x{li.quantity} @ ₹{li.unit_price}</Text>
              ))}
              <View style={s.row}>
                {next && (
                  <TouchableOpacity style={[s.btn, { flex: 1 }]} onPress={() => act(item, next.fn)}>
                    <Text style={s.btnText}>{next.label}</Text>
                  </TouchableOpacity>
                )}
                {CANCELLABLE.has(item.status) && (
                  <TouchableOpacity style={[s.btn, { flex: 1, backgroundColor: "#c0504d" }]}
                    onPress={() => cancel(item)}>
                    <Text style={s.btnText}>Cancel</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        }} />
    </View>
  );
}
