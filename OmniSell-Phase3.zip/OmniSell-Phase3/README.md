# OmniSell (Phase 1 + Phase 2a + Phase 3 merged)
Sell once. Sync everywhere.

## Backend
cd backend
pip install -r requirements.txt
cp .env.example .env        # DATABASE_URL hata do to SQLite chalega
python manage.py makemigrations accounts tenants catalog inventory marketplaces orders
python manage.py migrate
python manage.py test
python manage.py runserver 0.0.0.0:8000

Phase 2a adds: `marketplaces` app (channel connections, adapters: base/demo/shopify, registry, crypto for storing credentials encrypted).

Phase 3 adds: `orders` app — Order/OrderItem/Shipment/ReturnRequest, built on the Phase-1 inventory
ledger (order create reserves stock, ship converts reservation to a sale, cancel releases it,
return restocks). Full lifecycle: IMPORTED → CONFIRMED → PACKED → SHIPPED → DELIVERED, with
CANCELLED and RETURN_REQUESTED/RETURNED branches. Idempotency-key support on order creation so a
retried/duplicate webhook never double-books stock. Mobile: new "Orders" tab (create order, move
through statuses, cancel).

## Mobile (Expo)
npx create-expo-app@latest mobile --template blank   # sirf pehli baar
cd mobile && npx expo install expo-secure-store
copy mobile/ files over, then: cp src/config.example.js src/config.js  (URL daalo)
npx expo start --tunnel
