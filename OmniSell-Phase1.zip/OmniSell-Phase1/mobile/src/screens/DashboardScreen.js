import { useCallback, useEffect, useState } from "react";
import { RefreshControl, ScrollView, Text, View } from "react-native";
import { getDashboard } from "../api";
import { s } from "../ui";

const Stat = ({ label, value }) => (
  <View style={[s.card, { flex: 1, marginHorizontal: 4 }]}>
    <Text style={s.sub}>{label}</Text>
    <Text style={[s.name, { fontSize: 24 }]}>{value}</Text>
  </View>
);

export default function DashboardScreen() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setErr("");
    try { setD(await getDashboard()); } catch (e) { setErr(e.message); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ paddingBottom: 30 }}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor="#fff" />}>
      <Text style={s.title}>Dashboard</Text>
      {!!err && <Text style={s.err}>{err}</Text>}
      {d && (
        <View>
          <View style={{ flexDirection: "row" }}>
            <Stat label="Products" value={d.products} />
            <Stat label="SKUs" value={d.skus} />
          </View>
          <View style={{ flexDirection: "row" }}>
            <Stat label="On hand" value={d.total_on_hand} />
            <Stat label="Reserved" value={d.total_reserved} />
          </View>
          <Text style={[s.name, { marginVertical: 10 }]}>Low stock (≤ {d.low_stock_threshold})</Text>
          {d.low_stock.length === 0 && <Text style={s.sub}>Sab theek hai.</Text>}
          {d.low_stock.map((i) => (
            <View key={i.sku} style={s.card}>
              <Text style={s.name}>{i.sku_code}</Text>
              <Text style={s.sub}>{i.product} • Available {i.available}</Text>
            </View>
          ))}
          <Text style={[s.name, { marginVertical: 10 }]}>Recent activity</Text>
          {d.recent.length === 0 && <Text style={s.sub}>Abhi koi activity nahi.</Text>}
          {d.recent.map((e, i) => (
            <View key={i} style={s.card}>
              <Text style={s.name}>{e.sku_code}  {e.quantity_delta > 0 ? "+" : ""}{e.quantity_delta}</Text>
              <Text style={s.sub}>{e.entry_type} • {new Date(e.created_at).toLocaleString()}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}
