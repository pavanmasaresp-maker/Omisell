import { useCallback, useEffect, useState } from "react";
import { Alert, FlatList, RefreshControl, Text, TextInput, TouchableOpacity, View } from "react-native";
import { createProductWithSku, deleteProduct, getProducts, updateProduct, updateSku } from "../api";
import { s } from "../ui";

const STATUSES = ["DRAFT", "ACTIVE", "ARCHIVED"];
const allSkus = (p) => p.variants.flatMap((v) => v.skus);

export default function ProductsScreen() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [search, setSearch] = useState("");
  const [show, setShow] = useState(false);
  const [title, setTitle] = useState("");
  const [skuCode, setSku] = useState("");
  const [price, setPrice] = useState("");
  const [openId, setOpenId] = useState(null);
  const [edit, setEdit] = useState(null);

  const load = useCallback(async (q = "") => {
    setLoading(true); setErr("");
    try { setItems(await getProducts(q)); } catch (e) { setErr(e.message); }
    setLoading(false);
  }, []);
  useEffect(() => { load(""); }, [load]);

  async function add() {
    try {
      await createProductWithSku({ title: title.trim(), skuCode: skuCode.trim(), price });
      setTitle(""); setSku(""); setPrice(""); setShow(false); load(search);
    } catch (e) { setErr(e.message); }
  }

  function toggle(p) {
    if (openId === p.id) { setOpenId(null); return; }
    setOpenId(p.id);
    setEdit({
      title: p.title, status: p.status,
      prices: Object.fromEntries(allSkus(p).map((k) => [k.id, String(k.price)])),
    });
  }

  async function save(p) {
    try {
      await updateProduct(p.id, { title: edit.title.trim(), status: edit.status });
      for (const k of allSkus(p)) {
        if (edit.prices[k.id] !== String(k.price)) await updateSku(k.id, { price: edit.prices[k.id] });
      }
      setOpenId(null); load(search);
    } catch (e) { setErr(e.message); }
  }

  function remove(p) {
    Alert.alert("Delete karna hai?", p.title, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        try { await deleteProduct(p.id); setOpenId(null); load(search); }
        catch (e) { setErr(e.message); }
      } },
    ]);
  }

  return (
    <View style={s.screen}>
      <Text style={s.title}>Products</Text>
      <TextInput style={s.input} placeholder="Search (naam ya SKU)" placeholderTextColor="#777"
        value={search} onChangeText={setSearch} returnKeyType="search"
        onSubmitEditing={() => load(search)} />
      {!!err && <Text style={s.err}>{err}</Text>}
      <TouchableOpacity style={s.btn} onPress={() => setShow(!show)}>
        <Text style={s.btnText}>{show ? "Cancel" : "+ Add product"}</Text>
      </TouchableOpacity>
      {show && (
        <View>
          <TextInput style={s.input} placeholder="Title" placeholderTextColor="#777" value={title} onChangeText={setTitle} />
          <TextInput style={s.input} placeholder="SKU code" placeholderTextColor="#777" autoCapitalize="characters" value={skuCode} onChangeText={setSku} />
          <TextInput style={s.input} placeholder="Price" placeholderTextColor="#777" keyboardType="decimal-pad" value={price} onChangeText={setPrice} />
          <TouchableOpacity style={s.btn} onPress={add}><Text style={s.btnText}>Save</Text></TouchableOpacity>
        </View>
      )}
      <FlatList data={items} keyExtractor={(i) => i.id} extraData={[openId, edit]}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => load(search)} tintColor="#fff" />}
        ListEmptyComponent={<Text style={s.sub}>Koi product nahi.</Text>}
        renderItem={({ item }) => (
          <TouchableOpacity style={s.card} onPress={() => toggle(item)} activeOpacity={0.8}>
            <Text style={s.name}>{item.title}</Text>
            <Text style={s.sub}>{item.status} • {allSkus(item).map((k) => k.sku_code).join(", ") || "no SKU"}</Text>
            {openId === item.id && edit && (
              <View style={{ marginTop: 10 }}>
                <TextInput style={s.input} value={edit.title} placeholder="Title" placeholderTextColor="#777"
                  onChangeText={(t) => setEdit({ ...edit, title: t })} />
                <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
                  {STATUSES.map((st) => (
                    <TouchableOpacity key={st} style={[s.chip, edit.status === st && s.chipOn]}
                      onPress={() => setEdit({ ...edit, status: st })}>
                      <Text style={s.chipText}>{st}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                {allSkus(item).map((k) => (
                  <View key={k.id}>
                    <Text style={s.sub}>{k.sku_code} price</Text>
                    <TextInput style={s.input} keyboardType="decimal-pad" value={edit.prices[k.id]}
                      onChangeText={(t) => setEdit({ ...edit, prices: { ...edit.prices, [k.id]: t } })} />
                  </View>
                ))}
                <View style={s.row}>
                  <TouchableOpacity style={[s.btn, { flex: 1 }]} onPress={() => save(item)}><Text style={s.btnText}>Save</Text></TouchableOpacity>
                  <TouchableOpacity style={[s.btn, { flex: 1, backgroundColor: "#c0504d" }]} onPress={() => remove(item)}><Text style={s.btnText}>Delete</Text></TouchableOpacity>
                </View>
              </View>
            )}
          </TouchableOpacity>
        )} />
    </View>
  );
}
