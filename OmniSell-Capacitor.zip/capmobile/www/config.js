// Apna backend URL yahan daalo (Codespaces port-8000 public URL, aakhir mein / nahi).
const API_URL = "https://PASTE-YOUR-BACKEND-URL-HERE";
