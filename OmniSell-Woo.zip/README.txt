OmniSell WooCommerce overlay
Apply (repo root se):  unzip -o OmniSell-Woo.zip
Phir:  cd backend && python manage.py makemigrations marketplaces && python manage.py migrate && python manage.py test
Phir:  cd ../mobile && npx cap sync android   (naya APK banane ke liye)
