import { useEffect, useState } from "react";
import { Platform, SafeAreaView, ScrollView, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { me } from "./src/api";
import { clearToken, getToken } from "./src/storage";
import LoginScreen from "./src/screens/LoginScreen";
import DashboardScreen from "./src/screens/DashboardScreen";
import ProductsScreen from "./src/screens/ProductsScreen";
import InventoryScreen from "./src/screens/InventoryScreen";
import OrdersScreen from "./src/screens/OrdersScreen";
import ChannelsScreen from "./src/screens/ChannelsScreen";
import SyncScreen from "./src/screens/SyncScreen";

const SCREENS = {
  dashboard: DashboardScreen, products: ProductsScreen, inventory: InventoryScreen,
  orders: OrdersScreen, channels: ChannelsScreen, sync: SyncScreen,
};
const TABS = [["dashboard", "Dashboard"], ["products", "Products"], ["inventory", "Inventory"],
  ["orders", "Orders"], ["channels", "Channels"], ["sync", "Sync"]];

export default function App() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState("dashboard");

  async function check() {
    try { if (await getToken()) { await me(); setAuthed(true); } } catch { await clearToken(); }
    setReady(true);
  }
  useEffect(() => { check(); }, []);

  async function logout() { await clearToken(); setAuthed(false); }

  if (!ready) return <View style={{ flex: 1, backgroundColor: "#0f1115" }} />;
  const Screen = SCREENS[tab];
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#0f1115", paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 }}>
      <StatusBar barStyle="light-content" />
      {!authed ? <LoginScreen onLoggedIn={() => setAuthed(true)} /> : (
        <>
          <View style={{ flex: 1 }}><Screen /></View>
          <View style={{ backgroundColor: "#1b1e26" }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingVertical: 12, paddingHorizontal: 8 }}>
              {TABS.map(([k, label]) => (
                <TouchableOpacity key={k} style={{ paddingHorizontal: 14 }} onPress={() => setTab(k)}>
                  <Text style={{ color: tab === k ? "#4f7cff" : "#9aa3b2", fontWeight: "700" }}>{label}</Text>
                </TouchableOpacity>
              ))}
              <TouchableOpacity style={{ paddingHorizontal: 14 }} onPress={logout}>
                <Text style={{ color: "#9aa3b2", fontWeight: "700" }}>Logout</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}
