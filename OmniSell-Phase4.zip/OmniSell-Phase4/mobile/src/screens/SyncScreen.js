import { useCallback, useEffect, useState } from "react";
import { RefreshControl, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { getConnections, getJobs, getListings, getProducts, publishProduct, retryJob } from "../api";
import { s } from "../ui";

const COLORS = { ACTIVE: "#4cd964", SUCCEEDED: "#4cd964", PENDING: "#f5a623", RUNNING: "#f5a623",
  FAILED: "#ff6b6b", NEEDS_ACTION: "#ff9f0a", CONNECTED: "#4cd964" };
const Badge = ({ v }) => <Text style={{ color: COLORS[v] || "#9aa3b2", fontWeight: "700" }}>{v}</Text>;

export default function SyncScreen() {
  const [conns, setConns] = useState([]);
  const [products, setProducts] = useState([]);
  const [listings, setListings] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [connId, setConnId] = useState(null);
  const [productId, setProductId] = useState(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setErr("");
    try {
      const [c, p, l, j] = await Promise.all([getConnections(), getProducts(), getListings(), getJobs()]);
      setConns(c.filter((x) => x.status === "CONNECTED")); setProducts(p); setListings(l); setJobs(j);
    } catch (e) { setErr(e.message); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function publish() {
    setErr(""); setMsg("");
    if (!connId || !productId) { setErr("Channel aur product dono chuno."); return; }
    try {
      await publishProduct(productId, connId);
      setMsg("Job queue mein gaya. Worker chalte hi publish hoga, phir neeche ko refresh karo.");
      load();
    } catch (e) { setErr(e.message); }
  }
  async function retry(id) {
    try { await retryJob(id); load(); } catch (e) { setErr(e.message); }
  }

  const pending = jobs.filter((j) => j.status === "PENDING").length;
  return (
    <ScrollView style={s.screen} contentContainerStyle={{ paddingBottom: 30 }}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor="#fff" />}>
      <Text style={s.title}>Sync</Text>
      {!!err && <Text style={s.err}>{err}</Text>}
      {!!msg && <Text style={[s.sub, { marginBottom: 10 }]}>{msg}</Text>}

      <Text style={[s.name, { marginBottom: 8 }]}>1. Channel chuno</Text>
      {conns.length === 0 && <Text style={s.sub}>Pehle Channels tab mein channel connect karo.</Text>}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
        {conns.map((c) => (
          <TouchableOpacity key={c.id} style={[s.chip, connId === c.id && s.chipOn]} onPress={() => setConnId(c.id)}>
            <Text style={s.chipText}>{c.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={[s.name, { marginBottom: 8 }]}>2. Product chuno</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
        {products.map((p) => (
          <TouchableOpacity key={p.id} style={[s.chip, productId === p.id && s.chipOn]} onPress={() => setProductId(p.id)}>
            <Text style={s.chipText}>{p.title}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity style={s.btn} onPress={publish}><Text style={s.btnText}>Publish</Text></TouchableOpacity>

      <Text style={[s.name, { marginVertical: 10 }]}>Listings</Text>
      {listings.length === 0 && <Text style={s.sub}>Abhi koi listing nahi.</Text>}
      {listings.map((l) => (
        <View key={l.id} style={s.card}>
          <Text style={s.name}>{l.product_title}</Text>
          <Text style={s.sub}>{l.connection_name} {l.external_product_id ? "• " + l.external_product_id : ""}</Text>
          <Badge v={l.status} />
          {!!l.last_error && <Text style={s.err}>{l.last_error}</Text>}
        </View>
      ))}

      <Text style={[s.name, { marginVertical: 10 }]}>Jobs</Text>
      {pending > 0 && <Text style={s.sub}>{pending} job pending. Worker chal raha hai? (python manage.py run_sync_worker)</Text>}
      {jobs.length === 0 && <Text style={s.sub}>Abhi koi job nahi.</Text>}
      {jobs.map((j) => (
        <View key={j.id} style={s.card}>
          <Text style={s.name}>{j.job_type === "PUBLISH_PRODUCT" ? "Publish" : "Stock sync"} • {j.product_title}{j.sku_code ? " (" + j.sku_code + ")" : ""}</Text>
          <Text style={s.sub}>{j.connection_name} • attempt {j.attempts}/{j.max_attempts}</Text>
          <Badge v={j.status} />
          {!!j.last_error && <Text style={s.err}>{j.last_error}</Text>}
          {(j.status === "FAILED" || j.status === "NEEDS_ACTION") && (
            <TouchableOpacity style={[s.btn, { marginTop: 8, backgroundColor: "#262a35" }]} onPress={() => retry(j.id)}>
              <Text style={s.btnText}>Retry</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </ScrollView>
  );
}
